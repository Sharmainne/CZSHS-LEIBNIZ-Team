// #include <Wire.h>
// #include <I2Cdev.h>
// #include <NewPing.h>  // For ultrasonic sensors
// #include <MPU6050_6Axis_MotionApps20.h>
// #include <ESP32Servo.h>
// #include "Servo_Motor.h"  // Custom servo motor class
// #include "Gyro.h"  // Custom gyro class
// #include "Motor.h" 

// // Pin definitions
// #define I2C_SDA 21
// #define I2C_SCL 22
// #define ServoSteeringPin 27
// #define ServoCameraPin 4
// #define Motor_1 33
// #define Motor_2 32
// #define Ultra_Sonic_Trig_1 17
// #define Ultra_Sonic_Echo_1 36
// #define Ultra_Sonic_Trig_2 16
// #define Ultra_Sonic_Echo_2 39
// #define Ultra_Sonic_Trig_3 26
// #define Ultra_Sonic_Echo_3 34
// #define Ultra_Sonic_Trig_4 25
// #define Ultra_Sonic_Echo_4 35

// // MPU6050 myGyro; // Initialize MPU6050 with custom I2C pins
// Gyro myGyro(I2C_SDA, I2C_SCL); // Create an instance of the Gyro class with custom

// Motor myMotor(Motor_1, Motor_2, 20);

// Servo_Motor myServoSteering(ServoSteeringPin, 50, 500, 2500);
// Servo_Motor myServoCamera(ServoCameraPin, 50, 500, 2500); // Second servo motor instance

// NewPing mySonar1(Ultra_Sonic_Trig_1, Ultra_Sonic_Echo_1, 200); // Initialize ultrasonic sensor
// NewPing mySonar2(Ultra_Sonic_Trig_2, Ultra_Sonic_Echo_2, 200); // Initialize ultrasonic sensor
// NewPing mySonar3(Ultra_Sonic_Trig_3, Ultra_Sonic_Echo_3, 200); // Initialize ultrasonic sensor
// NewPing mySonar4(Ultra_Sonic_Trig_4, Ultra_Sonic_Echo_4, 200); // Initialize ultrasonic sensor

// void setup() {
//     Serial.begin(115200);
//     myGyro.setup(I2C_SDA, I2C_SCL); // Initialize the gyro with custom I2C pins
//     myServoSteering.write360(180);
//     // myMotor.write(255);
//     // delay(750);
// }

// void loop() {
//     myGyro.read();

//     // Read BOTH front sensors
//     int distance2 = mySonar2.ping_cm();  // Front 1
//     int distance3 = mySonar3.ping_cm();  // Front 2

//     // Take minimum front reading
//     int frontDist = min(distance2, distance3);

//     Serial.print("Front 1: "); Serial.println(distance2);
//     Serial.print("Front 2: "); Serial.println(distance3);
//     Serial.print("Chosen Front Dist: "); Serial.println(frontDist);

//     if (frontDist > 50 || frontDist == 0) {
//         // CLEAR path
//         myMotor.write(150);
//         myServoSteering.write360(180);
//     } else {
//         // OBSTACLE detected
//         int leftDist = mySonar1.ping_cm();
//         int rightDist = mySonar4.ping_cm();

//         Serial.print("Left: "); Serial.println(leftDist);
//         Serial.print("Right: "); Serial.println(rightDist);

//         if (leftDist > rightDist) {
//             myMotor.write(100);
//             myServoSteering.write360(135);
//             delay(650);
//             myServoSteering.write360(180);
//         } else {
//             myMotor.write(100);
//             myServoSteering.write360(225);
//             delay(650);
//             myServoSteering.write360(180);
//         }
//     }

//     delay(100);
// }
