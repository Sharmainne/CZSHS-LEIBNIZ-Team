// #include <Wire.h>
// #include <I2Cdev.h>
// #include <NewPing.h>  // For ultrasonic sensors
// #include <MPU6050_6Axis_MotionApps20.h>
// #include <ESP32Servo.h>
// #include <ArduinoOTA.h>
// #include "ultra_sonic.h"  // Custom ultrasonic sensor class
// #include "Display.h"  // For display handling
// #include "Servo_Motor.h"  // Custom servo motor class
// #include "Gyro.h"  // Custom gyro class
// #include "Motor.h" 
// #include "PID.h"

// const char* ssid = "YOUR_SSID";
// const char* password = "YOUR_PASSWORD";

// // Pin definitions
// #define I2C_SDA 21
// #define I2C_SCL 22
// #define ServoSteeringPin 4  
// #define ServoCameraPin 27
// #define Motor_1 33
// #define Motor_2 32 
// #define Ultra_Sonic_Trig_1 17
// #define Ultra_Sonic_Echo_1 36
// #define Ultra_Sonic_Trig_2 16
// #define Ultra_Sonic_Echo_2 39
// #define Ultra_Sonic_Trig_3 26
// #define Ultra_Sonic_Echo_3 34
// #define Ultra_Sonic_Trig_4 25
// #define Ultra_Sonic_Echo_4 35

// // U8G2_ST7920_128X64_F_SW_SPI u8g2(U8G2_R0, /* clock=*/ 18, /* data=*/ 23, /* CS=*/ 5, /* reset=*/ 22);

// Display myScreen(18, 23, 5, 22);  // Initialize display with pins

// Gyro myGyro(I2C_SDA, I2C_SCL);
// Motor myMotor(Motor_1, Motor_2);

// Servo_Motor myServoSteering(ServoSteeringPin, 50, 500, 2500, 180);
// Servo_Motor myServoCamera(ServoCameraPin, 50, 500, 2500, 180);

// Ultra_Sonics mySonars(Ultra_Sonic_Trig_1, Ultra_Sonic_Echo_1, 
//                       Ultra_Sonic_Trig_2, Ultra_Sonic_Echo_2, 
//                       Ultra_Sonic_Trig_3, Ultra_Sonic_Echo_3, 
//                       Ultra_Sonic_Trig_4, Ultra_Sonic_Echo_4);

// // NewPing mySonar1(Ultra_Sonic_Trig_1, Ultra_Sonic_Echo_1, 200);
// // NewPing mySonar2(Ultra_Sonic_Trig_2, Ultra_Sonic_Echo_2, 200);
// // NewPing mySonar3(Ultra_Sonic_Trig_3, Ultra_Sonic_Echo_3, 200); 
// // NewPing mySonar4(Ultra_Sonic_Trig_4, Ultra_Sonic_Echo_4, 200);

// int sonar1;
// int sonar2;
// int sonar3;
// int sonar4;

// void sonarRead();
// void checkRotation();

// int i = 0;  // Variable for display position

// void mysetup() {
//     Serial.begin(115200);

//     // Connect to WiFi
//     WiFi.begin(ssid, password);
//     while (WiFi.waitForConnectResult() != WL_CONNECTED) {
//         Serial.println("WiFi Connect Failed! Rebooting...");
//         delay(5000);
//         ESP.restart();
//     }


//     // myGyro.setup(I2C_SDA, I2C_SCL); // Initialize the gyro with custom I2C pins
//     u8g2.begin();  // Initialize the display
//     delay(1000);
// }

// void myloop() {
//     // myGyro.read(); // Read gyro data
//     // sonarRead();

//     Serial.println(".");

//     delay(10);  // Delay for readability
// }



// // void setup() {
// //     mysetup();
// // }

// // void loop() {
// //     myloop();
// // }