#include <Arduino.h>       // For basic Arduino functions
#include "Display.h"        // For display handling
#include "Ultra_Sonic.h"   // For Ultrasonic Sensors
#include "Servo_Motor.h"    // For Servo control
#include "Gyro.h"           // For Gyro Sensor
#include "Motor.h"          // For Motor control
#include "PID.h"            // For PID control
#include "Button.h"
#include "OTA.h"            // For OTA functionality

#define ButtonPin 15

#define Gyro_I2C_SDA 21
#define Gyro_I2C_SCL 22

#define ServoSteeringPin 27
#define ServoCameraPin 4

#define Motor_1 32
#define Motor_2 33

#define Ultra_Sonic_Trig_1 17
#define Ultra_Sonic_Echo_1 36
#define Ultra_Sonic_Trig_2 16
#define Ultra_Sonic_Echo_2 39
#define Ultra_Sonic_Trig_3 26
#define Ultra_Sonic_Echo_3 34
#define Ultra_Sonic_Trig_4 25
#define Ultra_Sonic_Echo_4 35

Button myButton(ButtonPin);
Gyro myGyro(Gyro_I2C_SDA, Gyro_I2C_SCL);
Motor myMotor(Motor_1, Motor_2);

Servo_Motor myServoSteering(ServoSteeringPin, 50, 500, 2500, 190, -30, 30);
Servo_Motor myServoCamera(ServoCameraPin, 50, 500, 2500, 180);

Ultra_Sonics mySonars(200,  Ultra_Sonic_Trig_1, Ultra_Sonic_Echo_1, 
                            Ultra_Sonic_Trig_2, Ultra_Sonic_Echo_2, 
                            Ultra_Sonic_Trig_3, Ultra_Sonic_Echo_3, 
                            Ultra_Sonic_Trig_4, Ultra_Sonic_Echo_4);

// Display myDisplay(18, 23, 5, &myGyro, &myMotor, &myButton, &myServoSteering, &myServoCamera, &mySonars);


// with display
//PID = 1.0, 0.0, 0.1 ; 100 ; smooth
//PID = 1.0, 0.0, 0.1 ; 180 ; smooth
//PID = 0.8, 0.0, 0.1 ; 180 ; smooth

//PID = 0.4, 0.0, 0.1 ; 255 ; smooth
//PID = 0.6, 0.0, 0.1 ; 225 ; smooth
//PID = 0.6, 0.0, 0.1 ; 200 ; smooth

//PID for Gyro steering
float KpGyro=0.6;
float KiGyro=0.0;
float KdGyro=0.1;

//PID for Wall Avoidance
float KpWall=0.05;
float KiWall=0.0;
float KdWall=0.01;

PID mySteeringPID(KpGyro, KiGyro, KdGyro); // PID for steering control
PID myWallSteer(KpWall, KiWall, KdWall, -75, 75);


// OTA myOTA("HONOR 90 Lite", "lebronpogi", "robot-esp32", "qwerty", &myDisplay);

void setup() {
  Serial.begin(115200);
  Serial.println("Robot ESP32 starting...");
  // myDisplay.setup();
  // myDisplay.status(1, "Starting ESP 32..");
  // myDisplay.displayData(); 
  // // myOTA.begin(&myButton);
  // myDisplay.changeState(EMERGENCY);
  // myDisplay.clearScreen();    
  
  // myDisplay.status(1, "Starting Gyro");
  // myDisplay.displayData(); 
  myGyro.setup();
  
  // myDisplay.status(1, "Starting Button");
  // myDisplay.displayData(); 
  myButton.setup();
  
  // myDisplay.status(1, "Starting Servo");
  // myDisplay.displayData();
  myServoSteering.write360(0);
  
  
  // // In your setup() function, replace the standby loop with:

  // myDisplay.changeState(NORMAL);
  // myDisplay.status(1, "Gyro stabilizing...");
  // myDisplay.status(2, "Please wait");
  // myDisplay.displayData();

  // // Wait for gyro to stabilize
  // while (!myGyro.isStabilized() || myButton.Pressed()) {
  //     myOTA.handle();
  //     myGyro.getData();
  //     myGyro.readAll();
  //     mySonars.read();
  //     myDisplay.status(1, "Gyro stabilizing...");
  //     myDisplay.status(2, "Please wait");
  //     myDisplay.statusf(3, "Reads: %d, %3.2f", myGyro.stabilizationSampleCount, myGyro.readX());
  //     myDisplay.displayData();
  //     delay(50); // Small delay to prevent overwhelming the display
  // }

  // Now wait for button press to start
  while (!myButton.Pressed()) {
      // myOTA.handle();
      myGyro.getData();
      myGyro.readAll();
      mySonars.read();
      // myDisplay.status(1, "Stand by...");
      // myDisplay.status(2, "Press to start");
      // myDisplay.displayData();
  }

  // myDisplay.statusClear();
}

//=============================================================//

int turn = 0;
int direction = 0;
int targetAngle = 0;
int turnTime = 0;
int nextTurn = 0;

int turntimemax = 25; // Maximum time to turn
int nextturnmax = 40; // Maximum time to wait before next turn
int totalwidth = 200; // Minimum distance to side wall for turning
int gyrodriftcompensation = 1.5; // Gyro drift compensation factor
int targetAngleRange = 10; // Acceptable range for target angle
int frontDistance = 200; // Maximum distance to front wall for turning

void loop() {
  // myOTA.handle();
  
  // Check if OTA is active - if so, skip the main robot logic
  // if (myOTA.isOTAActive()) return; // Exit loop early, don't execute robot code

  // myButton.update();
  // if (myButton.getPressTypeInt() == 4) {
  //   ESP.restart();
  // }
  
  
 
  myMotor.write(100); // gather sensor data


  myGyro.getData();
  myGyro.readAll();
  mySonars.read();

  targetAngle = ((turn * 90) - (turn * gyrodriftcompensation * -direction)) * direction;

  // logic to turn based on the following:
  // 1. the angle is within range of +/-10 of the target angle
  // 2. the front is is less than 

  //  if (mySonars.getFront() <= 100 && abs(myGyro.AccumAngleX - targetAngle) <= 10 && turnTime == 0 && nextTurn == 0) {
  //   turn++;
  //   turnTime = 10;
  //   nextTurn = 20;
  // }

  if ((targetAngle - targetAngleRange <= myGyro.AccumAngleX && myGyro.AccumAngleX <= targetAngle + targetAngleRange) 
      && mySonars.getFront() <= frontDistance
      && mySonars.getSide() >= totalwidth
      && nextTurn == 0
    ) {
    turn++;
    turnTime = turntimemax;
    nextTurn = nextturnmax;
    if (direction == 0) {
      if (mySonars.getLeft() > mySonars.getRight()) {
        direction = -1;
      } else {
        direction = 1;
      }
    }
  }

  // front obstacle avoidance
  int frontLeft = mySonars.sonar2; // Limit to 100 for avoidance logic
  int frontRight = mySonars.sonar3;
  int left = mySonars.sonar1;
  int right = mySonars.sonar4;

  int wallsteer = myWallSteer.read(0, left - right);

  int pid;
  if (turnTime == 0) {
    pid = mySteeringPID.read(wallsteer + targetAngle, myGyro.readAccumX());
  } else {
    pid = mySteeringPID.read(targetAngle, myGyro.readAccumX());
    turnTime--;
  }
  if (nextTurn != 0) {
    nextTurn--;
  }
  

  //calculate PID based on Gyro and add left and right wall avoidance
  myServoSteering.write360(-pid);

  // myDisplay.changeState(NORMAL);
  // myDisplay.statusf(1, "%d %d %d %d %2d",targetAngle - 10 <= myGyro.AccumAngleX,
                                        // myGyro.AccumAngleX <= targetAngle + 10,
                                        // mySonars.getFront() <= 80,
                                        // mySonars.getSide() >= 100,
                                        // turnTime;
  //                                   );
  // myDisplay.statusf(2, "%2d %2d %2d %2d %d", wallsteer, nextTurn, turnTime, -pid, direction);
  // myDisplay.statusf(3, "%2d %d | %3d %3d", turn, direction == 0 && mySonars.getLeft() > mySonars.getRight(), mySonars.getFront(), mySonars.getSide());
  // myDisplay.displayData();
    // Serial output for debugging instead of display

  Serial.print("TARGET: ");
  Serial.print(targetAngle); Serial.print(" ");
  Serial.print(" ANGLE: ");
  Serial.print(myGyro.AccumAngleX); Serial.print(" ");
  Serial.print(" Sonars: ");
  Serial.print(mySonars.getFrontLeft()); Serial.print(" ");
  Serial.print(mySonars.getFrontRight()); Serial.print(" ");
  Serial.print(mySonars.getFront()); Serial.print(" ");
  Serial.print(mySonars.getSide()); Serial.print(" ");
  Serial.print(mySonars.getLeft()); Serial.print(" ");
  Serial.print(mySonars.getRight()); Serial.print(" ");


  Serial.print(" COND: ");
  Serial.print(targetAngle - targetAngleRange <= myGyro.AccumAngleX); Serial.print(" ");
  Serial.print(myGyro.AccumAngleX <= targetAngle + targetAngleRange); Serial.print(" ");
  Serial.print(mySonars.getFront() <= frontDistance); Serial.print(" ");
  Serial.print(mySonars.getSide() >= totalwidth); Serial.print(" ");
  Serial.print(turnTime); Serial.print("");

  Serial.print(" WALLSTEER: ");
  Serial.print(wallsteer); Serial.print(" ");
  Serial.print(nextTurn); Serial.print(" ");
  Serial.print(turnTime); Serial.print(" ");
  Serial.print(-pid); Serial.print(" ");
  Serial.print(direction); Serial.print("");

  Serial.print(" TURN: ");
  Serial.print(turn); Serial.print(" ");
  Serial.print(direction == 0 && mySonars.getLeft() > mySonars.getRight()); Serial.print(" | ");
  Serial.print(mySonars.getFront()); Serial.print(" ");
  Serial.print(mySonars.getSide()); Serial.println();
}