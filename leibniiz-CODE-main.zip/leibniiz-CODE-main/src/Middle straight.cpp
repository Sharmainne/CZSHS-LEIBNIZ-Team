// #include <WiFi.h>           // For WiFi connection
// #include <ArduinoOTA.h>     // For Over-the-Air updates
// #include <NewPing.h>        // For Ultrasonic Sensors
// #include <Arduino.h>       // For basic Arduino functions
// #include "Display.h"        // For display handling
// #include "Ultra_Sonic.h"   // For Ultrasonic Sensors
// #include "Servo_Motor.h"    // For Servo control
// #include "Gyro.h"           // For Gyro Sensor
// #include "Motor.h"          // For Motor control
// #include "PID.h"            // For PID control
// #include "Button.h"

// #define ButtonPin 15

// #define Gyro_I2C_SDA 21
// #define Gyro_I2C_SCL 22

// #define ServoSteeringPin 27
// #define ServoCameraPin 4

// #define Motor_1 32
// #define Motor_2 33

// #define Ultra_Sonic_Trig_1 17
// #define Ultra_Sonic_Echo_1 36
// #define Ultra_Sonic_Trig_2 16
// #define Ultra_Sonic_Echo_2 39
// #define Ultra_Sonic_Trig_3 26
// #define Ultra_Sonic_Echo_3 34
// #define Ultra_Sonic_Trig_4 25
// #define Ultra_Sonic_Echo_4 35

// Button myButton(ButtonPin);
// Gyro myGyro(Gyro_I2C_SDA, Gyro_I2C_SCL);
// Motor myMotor(Motor_1, Motor_2);

// Servo_Motor myServoSteering(ServoSteeringPin, 50, 500, 2500, 180);
// Servo_Motor myServoCamera(ServoCameraPin, 50, 500, 2500, 180);

// Ultra_Sonics mySonars(Ultra_Sonic_Trig_1, Ultra_Sonic_Echo_1, 
//                       Ultra_Sonic_Trig_2, Ultra_Sonic_Echo_2, 
//                       Ultra_Sonic_Trig_3, Ultra_Sonic_Echo_3, 
//                       Ultra_Sonic_Trig_4, Ultra_Sonic_Echo_4);

// Display myDisplay(18, 23, 5, &myGyro, &myMotor, &myServoSteering, &myServoCamera, &mySonars);

// PID mySteeringPID(1, 0.0, 0.01); // PID for steering control
// PID myLeftWallSteer(1.5, 0.0, 0.01);
// PID myRightWallSteer(1.5, 0.0, 0.01);

// void mySetup() {
//   myGyro.setup();
//   myDisplay.setup();
//   myButton.setup();
//   myDisplay.clearScreen();
//   myServoSteering.clamp(-45,45);
//   myServoSteering.write360(10);
//   // Switch back to normal mode after OTA initialization
//   myDisplay.changeState(NORMAL);

//   while (myButton.pressed()) {
//     myGyro.getData();
//     myGyro.readAll();
//     mySonars.read();
//     myDisplay.status(1, "Stand by...");
//     myDisplay.status(2, "press to start");
//     myDisplay.status(3, "press to start");
//     myDisplay.displayData(); 
//     ArduinoOTA.handle();
//     delay(10);
//   }
//   myDisplay.statusClear();
// }

// int i = -180;  // Variable for display position
// int turn = 0;

// void myLoop() {
//   // gather sensor data
//   myMotor.write(150);
//   myGyro.getData();
//   myGyro.readAll();
//   mySonars.read();

//   //calculate left and right PID
//   int left = myLeftWallSteer.read(30,mySonars.getLeft());
//   int right = myRightWallSteer.read(30,mySonars.getRight());
//   int leftDist = mySonars.getLeft();
//   int rightDist = mySonars.getRight();
  

//   //display left and right PID
//   myDisplay.statusf(2, "%d %d",left, right);
//   myDisplay.statusf(3, "%d",left - right);

//   //calculate PID based on Gyro and add left and right wall avoidance
//   int pid = mySteeringPID.read(left - right, myGyro.readAccumX());


//   myServoSteering.write360(-pid);
//   myDisplay.statusf(1, "%d", -pid);
//   myDisplay.displayData();

// if (leftDist < 30) {
//   steer = myPIDSteering.read(90, myGyro.readX());
// }

//   Serial.println();
//   delay(10);
// }

// //======================================//
// //   WIFI! : OVER THE AIR CONNECTION    //
// // DONT TOUCH! UNLESS FINAL COMPETITION //
// //======================================//

// const char* ssid = "HONOR 90 Lite";
// const char* password = "lebronpogi";

// // OTA settings
// const char* otaHostname = "robot-esp32";
// const char* otaPassword = "qwerty";  

// void setup() {
//   Serial.begin(115200);
//   Serial.println("Robot ESP32 starting...");
  
//   // Initialize display first
//   myDisplay.setup();
//   myDisplay.changeState(UPDATING);
//   myDisplay.setOTAStage(OTA_WIFI_CONNECTING);
//   myDisplay.displayData();
  
//   // Connect to WiFi
//   WiFi.mode(WIFI_STA);
//   WiFi.begin(ssid, password);
  
//   while (WiFi.waitForConnectResult() != WL_CONNECTED) {
//     Serial.println("WiFi connection failed! Retrying...");
//     myDisplay.setOTAStage(OTA_WIFI_CONNECTING);
//     myDisplay.displayData();
//     delay(5000);
//     ESP.restart();
//   }
  
//   Serial.println("WiFi connected!");
//   Serial.print("IP address: ");
//   Serial.println(WiFi.localIP());
  
//   // Update display with WiFi connection success
//   myDisplay.setOTAStage(OTA_WIFI_CONNECTED);
//   myDisplay.setIPAddress(WiFi.localIP().toString());
//   myDisplay.displayData();
//   delay(1000);
  
//   // Configure OTA
//   myDisplay.setOTAStage(OTA_INITIALIZING);
//   myDisplay.displayData();
  
//   ArduinoOTA.setHostname(otaHostname);
//   ArduinoOTA.setPassword(otaPassword);
  
//   ArduinoOTA.onStart([]() {
//     Serial.println("OTA Update Starting...");
//     myDisplay.setOTAStage(OTA_UPDATING);
//     myDisplay.setOTAProgress(0);
//     myDisplay.displayData();
//   });
  
//   ArduinoOTA.onEnd([]() {
//     Serial.println("\nOTA Update Complete!");
//     myDisplay.setOTAStage(OTA_COMPLETE);
//     myDisplay.displayData();
//     delay(2000);
//   });
  
//   ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
//     unsigned int progressPercent = (progress / (total / 100));
//     Serial.printf("Progress: %u%%\r", progressPercent);
//     myDisplay.setOTAProgress(progressPercent);
//     myDisplay.displayData();
    
//     // Force immediate display update and yield to system
//     yield();
//     delay(10); // Small delay to ensure display updates
//   });
  
//   ArduinoOTA.onError([](ota_error_t error) {
//     Serial.printf("OTA Error[%u]: ", error);
//     String errorMsg = "";
//     if (error == OTA_AUTH_ERROR) {
//       errorMsg = "Auth Failed";
//       Serial.println("Auth Failed");
//     } else if (error == OTA_BEGIN_ERROR) {
//       errorMsg = "Begin Failed";
//       Serial.println("Begin Failed");
//     } else if (error == OTA_CONNECT_ERROR) {
//       errorMsg = "Connect Failed";
//       Serial.println("Connect Failed");
//     } else if (error == OTA_RECEIVE_ERROR) {
//       errorMsg = "Receive Failed";
//       Serial.println("Receive Failed");
//     } else if (error == OTA_END_ERROR) {
//       errorMsg = "End Failed";
//       Serial.println("End Failed");
//     }
    
//     myDisplay.setOTAStage(OTA_ERROR);
//     myDisplay.setOTAError(errorMsg);
//     myDisplay.displayData();
//     delay(5000);
//   });
  
//   ArduinoOTA.begin();
  
//   Serial.println("OTA Ready!");
//   Serial.printf("To upload wirelessly: pio run -t upload --upload-port %s\n", WiFi.localIP().toString().c_str());
  
//   // Show OTA Ready status
//   myDisplay.setOTAStage(OTA_READY);
//   myDisplay.displayData();
//   delay(2000);
  
//   // Initialize your robot code here
//   mySetup();
// }

// void loop() {
//   // Handle OTA updates
//   ArduinoOTA.handle();
  
//   // Your robot main loop
//   myLoop();
// }