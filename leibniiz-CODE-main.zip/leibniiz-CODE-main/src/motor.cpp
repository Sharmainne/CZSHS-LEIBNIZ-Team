// #include <Arduino.h>

// #define Motor_1 32
// #define Motor_2 33

// int i = 35;

// void setup()
// {
//     Serial.begin(115200);
//     pinMode(Motor_1, OUTPUT);
//     pinMode(Motor_2, OUTPUT);
// }

// void loop()
// {
//     analogWrite(Motor_1, i--);
//     analogWrite(Motor_2, LOW);
//     Serial.println(i);
//     delay(2000);
// }