#include "OTA.h"

// Constructor with display
OTA::OTA(const char* ssid, const char* password, const char* hostname, const char* otaPassword, Display* display)
    : ssid(ssid), password(password), otaHostname(hostname), otaPassword(otaPassword), display(display), 
      cancelButton(nullptr), useDisplay(true), useCancelButton(false), otaActive(false) {}

// Constructor without display
OTA::OTA(const char* ssid, const char* password, const char* hostname, const char* otaPassword)
    : ssid(ssid), password(password), otaHostname(hostname), otaPassword(otaPassword), display(nullptr), 
      cancelButton(nullptr), useDisplay(false), useCancelButton(false), otaActive(false) {}

void OTA::displayMessage(const char* message, int line) {
    if (useDisplay && display != nullptr) {
        display->status(line, message);
        display->displayData();
    }
}

void OTA::displayMessagef(int line, const char* format, ...) {
    if (useDisplay && display != nullptr) {
        va_list args;
        va_start(args, format);
        
        // Create a buffer for formatted string
        char buffer[128];
        vsnprintf(buffer, sizeof(buffer), format, args);
        
        va_end(args);
        
        display->status(line, buffer);
        display->displayData();
    }
}

void OTA::connectWiFi() {
    Serial.println("Connecting to WiFi...");
    
    // Set OTA as active and display to OTA mode FIRST
    otaActive = true;
    if (useDisplay && display != nullptr) {
        Serial.println("Setting display to UPDATING state");
        display->changeState(UPDATING);
        display->setOTAStage(OTA_WIFI_CONNECTING);
        display->displayData();
        delay(100);
    }
    
    displayMessage("Connecting WiFi...", 1);
    
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);
    
    int attempts = 0;
    const unsigned long connectionTimeout = 10000; // 10 seconds timeout per attempt
    
    while (attempts < 10) {
        attempts++;
        Serial.printf("WiFi connection attempt %d (Press button to cancel)\n", attempts);
        
        // Ensure display stays in OTA mode
        if (useDisplay && display != nullptr) {
            display->changeState(UPDATING);
            display->setOTAStage(OTA_WIFI_CONNECTING);
        }
        
        displayMessagef(1, "WiFi Attempt %d", attempts);
        displayMessage("Press btn to cancel", 2);
        
        unsigned long startTime = millis();
        
        // Non-blocking wait with cancel button checking
        while (WiFi.status() != WL_CONNECTED && (millis() - startTime) < connectionTimeout) {
            // Check for cancel button press every 100ms
            if (checkCancelButton()) {
                Serial.println("OTA cancelled by button press");
                displayMessage("OTA Cancelled", 1);
                if (useDisplay && display != nullptr) {
                    display->changeState(UPDATING);
                    display->setOTAStage(OTA_ERROR);
                    display->setOTAError("Cancelled");
                    display->displayData();
                    delay(2000);
                    // Return to normal mode after showing error
                    display->changeState(NORMAL);
                    display->displayData();
                }
                WiFi.disconnect();
                otaActive = false; // Cancel OTA
                return;
            }
            delay(100);
        }
        
        // Check if we successfully connected
        if (WiFi.status() == WL_CONNECTED) {
            break;
        }
        
        // If we've tried too many times, give up
        if (attempts >= 10) {
            Serial.println("Too many failed attempts, giving up...");
            displayMessage("WiFi Failed", 1);
            displayMessage("Too many attempts", 2);
            if (useDisplay && display != nullptr) {
                display->changeState(UPDATING);
                display->setOTAStage(OTA_ERROR);
                display->setOTAError("WiFi Failed");
                display->displayData();
                delay(2000);
                // Return to normal mode after showing error
                display->changeState(NORMAL);
                display->displayData();
            }
            otaActive = false; // WiFi failed, cancel OTA
            return;
        }
        
        Serial.printf("WiFi connection failed! Attempt %d failed\n", attempts);
        delay(1000);
    }
    
    Serial.println("WiFi connected!");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
    
    displayMessage("WiFi Connected!", 1);
    displayMessagef(2, "IP: %s", WiFi.localIP().toString().c_str());
    
    if (useDisplay && display != nullptr) {
        Serial.println("Updating display with WiFi connected status");
        display->changeState(UPDATING);
        display->setOTAStage(OTA_WIFI_CONNECTED);
        display->setIPAddress(WiFi.localIP().toString());
        display->displayData();
        delay(2000);
    }
}

void OTA::setupOTA() {
    Serial.println("Setting up OTA...");
    
    // Ensure display stays in OTA mode
    if (useDisplay && display != nullptr) {
        display->changeState(UPDATING);
        display->setOTAStage(OTA_INITIALIZING);
        display->displayData();
    }
    
    displayMessage("Setting up OTA...", 1);
    
    ArduinoOTA.setHostname(otaHostname);
    ArduinoOTA.setPassword(otaPassword);
    
    displayMessagef(1, "Host: %s", otaHostname);
    displayMessage("OTA Configured", 2);
    
    ArduinoOTA.onStart([this]() {
        Serial.println("OTA Update Starting...");
        // CRITICAL: Ensure OTA is active and display is in OTA mode
        otaActive = true;
        if (useDisplay && display != nullptr) {
            display->changeState(UPDATING);
            display->setOTAStage(OTA_UPDATING);
            display->setOTAProgress(0);
            display->displayData();
        }
        displayMessage("OTA Starting...", 1);
    });
    
    ArduinoOTA.onEnd([this]() {
        Serial.println("\nOTA Update Complete!");
        if (useDisplay && display != nullptr) {
            display->changeState(UPDATING);
            display->setOTAStage(OTA_COMPLETE);
            display->displayData();
            delay(2000);
        }
        displayMessage("OTA Complete!", 1);
        displayMessage("Rebooting...", 2);
        // Note: Device will reboot, so don't set otaActive = false
    });
    
    ArduinoOTA.onProgress([this](unsigned int progress, unsigned int total) {
        unsigned int progressPercent = (progress / (total / 100));
        Serial.printf("Progress: %u%%\r", progressPercent);
        
        // CRITICAL: Ensure display stays in OTA mode during upload
        if (useDisplay && display != nullptr) {
            display->changeState(UPDATING);
            display->setOTAStage(OTA_UPDATING);
            display->setOTAProgress(progressPercent);
            display->displayData();
        }
        
        displayMessagef(1, "Progress: %u%%", progressPercent);
        yield();
        delay(10);
    });
    
    ArduinoOTA.onError([this](ota_error_t error) {
        Serial.printf("OTA Error[%u]: ", error);
        String errorMsg = "";
        if (error == OTA_AUTH_ERROR) {
            errorMsg = "Auth Failed";
            Serial.println("Auth Failed");
        } else if (error == OTA_BEGIN_ERROR) {
            errorMsg = "Begin Failed";
            Serial.println("Begin Failed");
        } else if (error == OTA_CONNECT_ERROR) {
            errorMsg = "Connect Failed";
            Serial.println("Connect Failed");
        } else if (error == OTA_RECEIVE_ERROR) {
            errorMsg = "Receive Failed";
            Serial.println("Receive Failed");
        } else if (error == OTA_END_ERROR) {
            errorMsg = "End Failed";
            Serial.println("End Failed");
        }
        
        displayMessage("OTA Error!", 1);
        displayMessage(errorMsg.c_str(), 2);
        
        if (useDisplay && display != nullptr) {
            display->changeState(UPDATING);
            display->setOTAStage(OTA_ERROR);
            display->setOTAError(errorMsg);
            display->displayData();
            delay(2000);
            // Return to normal mode after showing error
            display->changeState(NORMAL);
            display->displayData();
        }
        
        otaActive = false; // OTA failed, no longer active
    });
    
    ArduinoOTA.begin();
    
    Serial.println("OTA Ready!");
    Serial.printf("To upload wirelessly: pio run -t upload --upload-port %s\n", WiFi.localIP().toString().c_str());
    
    displayMessage("OTA Ready!", 1);
    displayMessagef(2, "Upload to: %s", WiFi.localIP().toString().c_str());
    
    if (useDisplay && display != nullptr) {
        display->changeState(UPDATING);
        display->setOTAStage(OTA_READY);
        display->displayData();
        delay(2000);
        // After setup is complete, return to normal mode
        display->changeState(NORMAL);
        display->displayData();
    }
    
    // OTA setup complete, robot can continue normal operation
    otaActive = false;
}

void OTA::begin() {
    Serial.println("OTA: Begin called");
    displayMessage("OTA: Begin called", 1);
    displayMessage("OTA Starting...", 1);
    connectWiFi();
    
    // Only setup OTA if WiFi connected successfully
    if (WiFi.status() == WL_CONNECTED) {
        setupOTA();
    } else {
        Serial.println("OTA: WiFi connection failed, skipping OTA setup");
        displayMessage("OTA SKIPPED", 1);
        displayMessage("WiFi not connected", 2);
        delay(2000);
        otaActive = false;
    }
    Serial.println("OTA: Initialization complete");
    displayMessage("OTA: Init complete", 1);
}

void OTA::begin(Button* cancelBtn) {
    cancelButton = cancelBtn;
    useCancelButton = true;
    begin();
}

bool OTA::checkCancelButton() {
    if (useCancelButton && cancelButton != nullptr) {
        return cancelButton->Pressed();
    }
    return false;
}

void OTA::handle() {
    ArduinoOTA.handle();
}

bool OTA::isConnected() {
    return WiFi.status() == WL_CONNECTED;
}

String OTA::getIPAddress() {
    return WiFi.localIP().toString();
}

bool OTA::isOTAActive() {
    return otaActive;
}

void OTA::endOTAMode() {
    otaActive = false;
    if (useDisplay && display != nullptr) {
        display->changeState(NORMAL);
        display->displayData();
    }
}