#ifndef OTA_H
#define OTA_H

#include <WiFi.h>
#include <ArduinoOTA.h>
#include "Display.h"
#include "Button.h"

class OTA {
private:
    const char* ssid;
    const char* password;
    const char* otaHostname;
    const char* otaPassword;
    Display* display;
    Button* cancelButton;
    bool useDisplay;
    bool useCancelButton;
    bool otaActive;  // Track if OTA is active
    
    void connectWiFi();
    void setupOTA();
    bool checkCancelButton();
    void displayMessage(const char* message, int line = 1);
    void displayMessagef(int line, const char* format, ...);
    void setDisplayOTAMode();  // Helper method
    
public:
    // Constructor with display
    OTA(const char* ssid, const char* password, const char* hostname, const char* otaPassword, Display* display);
    
    // Constructor without display
    OTA(const char* ssid, const char* password, const char* hostname, const char* otaPassword);
    
    // Initialize OTA (call in setup())
    void begin();
    
    // Initialize OTA with button cancel option
    void begin(Button* cancelButton);
    
    // Handle OTA updates (call in loop())
    void handle();
    
    // Get WiFi status
    bool isConnected();
    
    // Get IP address
    String getIPAddress();
    
    // Check if OTA is currently active
    bool isOTAActive();
    
    // Force end OTA mode (call when OTA is done)
    void endOTAMode();
};

#endif